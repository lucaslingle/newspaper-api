# -*- coding: utf-8 -*-
"""
To change the version of entire package, just edit this one location.
"""
__title__ = 'newspaper'
__author__ = 'Lucas Ou-Yang'
__license__ = 'MIT'
__copyright__ = 'Copyright 2014, Lucas Ou-Yang'

version_info = (0, 1, 0, 7)
__version__ = ".".join(map(str, version_info))
